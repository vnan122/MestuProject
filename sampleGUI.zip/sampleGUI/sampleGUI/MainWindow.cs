using System;
using Gtk;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;

public partial class MainWindow: Gtk.Window
{	
	public MainWindow (): base (Gtk.WindowType.Toplevel)
	{
		Build ();
	}
	
	protected void OnDeleteEvent (object sender, DeleteEventArgs a)
	{
		Gtk.Application.Quit ();
		a.RetVal = true;
	}

	protected void OnButton1Clicked (object sender, System.EventArgs e)
	{
		textview2.Buffer.Text = ""; 
	
	    var watch = Stopwatch.StartNew();
	    for (int i = 2; i < 20; i++)
	    {
	        var result = SumRootN(i);
	        textview2.Buffer.Text += "root " + i.ToString() + " --> " +
	                           result.ToString() + Environment.NewLine;
	
	    }
	    var time = watch.ElapsedMilliseconds;
		textview3.Buffer.Text = time.ToString();
	}
	
	public static double SumRootN(int root)
    {
        double result = 0;
        for (int i = 1; i < 10000000; i++)
        {
            result += Math.Exp(Math.Log(i) / root);
        }
        return result;
    }
	
	int clicks = 0;
	protected void OnButton2Clicked (object sender, System.EventArgs e)
	{
		clicks ++;
		textview1.Buffer.Text = clicks.ToString();
	}

	protected void OnButton3Clicked (object sender, System.EventArgs e)
	{
		textview2.Buffer.Text = "";
	    var watch = Stopwatch.StartNew();
		
//		Parallel.For(2, 20, (i) =>
//		{
//		    var result = SumRootN(i);
//		    this.Dispatcher.BeginInvoke(new Action(() =>
//		        textBlock1.Text += "root " + i.ToString() + " " +
//		                           result.ToString() + Environment.NewLine)
//		         , null);
//		});
		Parallel.For(2, 20, (i) =>
		{
		    var result = SumRootN(i);
		     textview2.Buffer.Text += "root " + i.ToString() + " " +
		                       result.ToString() + Environment.NewLine;
		
		});
	    var time = watch.ElapsedMilliseconds;
		textview3.Buffer.Text = time.ToString();
	}

	protected void OnButton4Clicked (object sender, System.EventArgs e)
	{	
		textview2.Buffer.Text = "";
	    var watch = Stopwatch.StartNew();
		List<Task> task = new List<Task>();
		textview3.Buffer.Text = Thread.CurrentThread.ToString();
		for (int i = 2; i < 20; i++)
	    {
			int j = i;
			var t = Task.Factory.StartNew(()=>
			                             {
	        var result = SumRootN(i);
	        textview2.Buffer.Text += "root " + j.ToString() + " --> " +
	                           result.ToString() + Environment.NewLine;
			});
			task.Add(t);
	    }
		
		
		Task.Factory.ContinueWhenAll(task.ToArray(),result =>
		                            {
			String d = Thread.CurrentThread.ToString();
			var time = watch.ElapsedMilliseconds;
			textview3.Buffer.Text = time.ToString();
		});
		
	}
	
	protected void OnButton6Clicked (object sender, System.EventArgs e)
	{
		textview1.Buffer.Text = "";
		textview2.Buffer.Text = "";
		textview3.Buffer.Text = "";
		clicks = 0;
	}
}
