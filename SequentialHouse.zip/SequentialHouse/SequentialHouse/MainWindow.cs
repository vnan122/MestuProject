using System;
using System.Drawing;
using Gtk;
using Cairo;

public partial class MainWindow: Gtk.Window
{	
	public MainWindow (): base (Gtk.WindowType.Toplevel)
	{
		Build ();
	}
	
	protected void OnDeleteEvent (object sender, DeleteEventArgs a)
	{
		Application.Quit ();
		a.RetVal = true;
	}

	protected void OnButton1Clicked (object sender, System.EventArgs e)
	{
		DrawHouseBase();
	}
	
		private System.Drawing.Graphics g;
		private System.Drawing.Pen pen1 = new System.Drawing.Pen(Color.Blue, 2F);
	private void DrawHouseBase()
	{
		Rectangle r = new Rectangle(150,10,100,100);
		g.DrawRectangle(pen1,r);
		
//		Cairo.Context cr = Gdk.CairoHelper.Create (drawingarea2.GdkWindow);
//		cr.LineWidth = 0.1;
//		cr.Rectangle(100,300,500,50);
//		cr.Stroke();
	}
	
}